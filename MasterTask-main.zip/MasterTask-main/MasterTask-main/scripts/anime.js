const sr = ScrollReveal({
    origin: 'top',
    distance: '30px',
    duration: 2000,
    reset: true
});

sr.reveal(`.hero-container, .btn-container,.img,
            .feature-content`, {
    interval: 200
})