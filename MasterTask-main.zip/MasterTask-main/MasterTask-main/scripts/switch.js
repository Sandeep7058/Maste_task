const button = document.querySelector('.switch-btn');
button.addEventListener('click', () => {
    console.log('Button clicked');
    document.body.classList.toggle('dark-theme');
});