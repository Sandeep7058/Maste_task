const loginBtn = document.querySelector('.login');
const loginForm = document.querySelector('.form_container_login');
const closeBtn = document.querySelector('.form_close_login');

loginBtn.addEventListener('click', () => {
    console.log('clicked');
   openModel()
})
closeBtn.addEventListener('click', () => {
    closeModel()
})


// document.addEventListener('keydown',(event)=>{
//     if(event.key==='Backspace'){
//         closeModel();
//     }
// })

function openModel(){
    loginForm.classList.add('activelogin');
}
function closeModel(){
    loginForm.classList.remove('activelogin');
}


const registerBtn = document.querySelector('.get-started');
const registerForm = document.querySelector('.form_container');
const closeBtnl = document.querySelector('.form_close');

registerBtn.addEventListener('click', () => {
   openModell()
})
closeBtnl.addEventListener('click', () => {
    closeModell()
})

// window.onload = function() {
//     setTimeout(function() {
//         registerForm.classList.add('active');
//     }, 4000);
// }

// document.addEventListener('keydown',(event)=>{
//     if(event.key==='Backspace'){
//         closeModell();
//     }
// })

function openModell(){
    registerForm.classList.add('active');
}
function closeModell(){
    registerForm.classList.remove('active');
}


